CSS
=======
Cascading style sheets 

CSS using for make decorations to web page or give styles for web page .
CSS is not programming 

CSS is simple sytax 

types of CSS
============
1.inline CSS
2.internal css 
3.external css 

1.inline CSS
====================
  element specific css 
  each and every element we need add css 

  <h1 style=' attribute1;  attribute1; attribute1;'>  </h1>
  <h2 style=''>  </h2>

2.internal css 
=======================
 page specific css 
  
  <style>
       selectors ...

       h1 { attribute1;  attribute1;  attribute1;  }
       div { attribute1;  attribute1;  attribute1; }

       h1 { color:red ; background-color:lightblue; }
  </style>

  selector 
  ========== selector is selecting a group of elements in side css .

  3.external css 
  ====================
    application level css 

     one css file will be accessed for all html pages .

     file.css
     ==========

     selectors ...

       h1 { attribute1;  attribute1;  attribute1;  }
       div { attribute1;  attribute1;  attribute1; }
       h1 { color:red ; background-color:lightblue; }

  first_page.html
  =================
     <link rel='stylesheet' href='file.css' />

  
  first_page.html
  =================
  <link rel='stylesheet' href='file.css' />
  
  first_page.html
  =================
   <link rel='stylesheet' href='file.css' />

   note 
   ==== in css attribute and value separated with : 

   every attribute separated with ; 


   font-properties 
   =================

   font-family
   font-style
   font-weight 

   text-properties 
   ================
   text-decoration
   text-indent 
   text-align
   text-transform
   line-height
   word-spacing 