alert("external js is loading")

alert('how r u js ?')